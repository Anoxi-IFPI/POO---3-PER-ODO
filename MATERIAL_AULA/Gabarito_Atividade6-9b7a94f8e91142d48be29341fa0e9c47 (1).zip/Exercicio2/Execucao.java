package Exercicio2;

import javax.swing.JOptionPane;

public class Execucao {
    public static void main(String[] args) {
        Lampada l2 = new Lampada();
        Lampada l1 = new Lampada();
        l2.setEstado(false);
        l1.setEstado(true);

        l1.apagar();
        l2.acender();

        System.out.println(l1.getEstado());

    }
    
}