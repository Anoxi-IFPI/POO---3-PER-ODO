package Exercicio2;
/**
 * Teste Lampada
 */
public class Lampada {
    private boolean estado; 

    public boolean getEstado(){
        return estado;
    }

    public void setEstado(boolean valor){
        estado = valor;
    }

    public void acender(){
        estado = true;
    }

    public void apagar(){
        estado = false;
    }

}
