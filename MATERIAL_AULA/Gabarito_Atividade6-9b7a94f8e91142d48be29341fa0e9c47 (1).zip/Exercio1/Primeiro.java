package Exercio1;
import javax.swing.JOptionPane;

class Primeiro{
	public static void main(String string[]){
		Aluno a1 = new Aluno();
		a1.setNome("José");
		a1.setMedia(8.5);

		String msg = a1.getNome() + ":"+ a1.calcularSituacao();
		JOptionPane.showMessageDialog(null,msg);
	}
}
