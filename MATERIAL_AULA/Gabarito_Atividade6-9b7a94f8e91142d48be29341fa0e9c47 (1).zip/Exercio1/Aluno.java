package Exercio1;
public class Aluno {
    private String nome;
    private double media;

    public void setNome(String valor){
        nome = valor;
    }

    public String getNome(){
        return nome;
    }

    public void setMedia(double novaMedia){
        media = novaMedia;
    }

    public double getMedia(){
        return media;
    }

    public String calcularSituacao(){
        if (media >= 7) {
            return "Aprovado";
        }else{
            return "Reprovado";
        }
    }    
}