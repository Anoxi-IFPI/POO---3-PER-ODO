public class Aluno {
    public String nome;
    public double nota1, nota2, nota3;

}
