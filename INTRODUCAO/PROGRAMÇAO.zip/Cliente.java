public class Cliente {
    public String nome;
    public String cpf;
    public String codigo;

}
