public class Funcionario {
    public String nome, matricula;
    public double salario;

}