public class AppLampada {
    public static void main(String[] args) {
        Lampada l1 = new Lampada();
        l1.acesa = true;
        System.out.print(l1.acesa);
    }

}
