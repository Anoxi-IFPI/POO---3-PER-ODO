public class Lampada {
    public boolean acesa;
}
