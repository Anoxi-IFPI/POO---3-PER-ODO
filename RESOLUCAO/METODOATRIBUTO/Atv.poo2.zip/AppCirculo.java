public class AppCirculo {
    public static void main(String[] args) {
        Circulo c1 = new Circulo();
        c1.raio = 10;
        System.out.print("Area do circulo: " + c1.CalcularArea());
    }

}
