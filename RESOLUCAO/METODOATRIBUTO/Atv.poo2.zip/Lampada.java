public class Lampada {
    public boolean acesa;

    public void acender() {
        acesa = false;
    }

    public void apagar() {
        acesa = true;
    }
}
