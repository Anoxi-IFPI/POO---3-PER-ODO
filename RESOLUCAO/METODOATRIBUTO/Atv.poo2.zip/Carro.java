public class Carro {
    public int velocidade;

    public int acelerar() {
        return ++velocidade;
    }

    public int frear() {
        return --velocidade;
    }

}
