public class AppLampada {
    public static void main(String[] args) {
        Lampada l1 = new Lampada();
        System.out.print("acesa: " + l1.acesa);
    }
}