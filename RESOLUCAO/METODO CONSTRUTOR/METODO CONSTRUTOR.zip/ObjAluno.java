public class ObjAluno {
    public static void main(String[] args) {
        Aluno a1 = new Aluno("antonio");
        a1.aluno();
        a1.setMedia();
        a1.getMedia();
        a1.situacaoAluno();

    }
}